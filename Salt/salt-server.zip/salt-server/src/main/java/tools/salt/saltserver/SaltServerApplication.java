package tools.salt.saltserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaltServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaltServerApplication.class, args);
	}

}

